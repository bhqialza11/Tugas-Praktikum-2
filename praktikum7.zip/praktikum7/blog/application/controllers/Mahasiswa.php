<?php
class Mahasiswa extends CI_Controller{
    // membuat method index
    public function index(){
        $this->load->model('mahasiswa_model','mhs1');

        // buat object model 1 dan nilai nya
        $this->mhs1->id=1;
        $this->mhs1->nim='01232';
        $this->mhs1->nama='Raihan';
        $this->mhs1->gender='L';
        $this->mhs1->ipk=3.95;

        $this->load->model('mahasiswa_model','mhs2');

        // buat object model 2 dan nilai nya
        $this->mhs2->id=2;
        $this->mhs2->nim='01274';
        $this->mhs2->nama='Amel';
        $this->mhs2->gender='P';
        $this->mhs2->ipk=3.75;

        // simpan object yang kita buat tadi ke dalam array
        $list_mhs = [$this->mhs1, $this->mhs2];
        // Siapkan data untuk di kirim kedalam view, dimana data nya di ambil dari object yang kita simpan ke dalam array
        $data['list_mhs'] = $list_mhs;
        // render data dan kirim data ke dalam view
        $this->load->view('layouts/header');
        $this->load->view('mahasiswa/index', $data);
        $this->load->view('layouts/footer');
    }
    // Method Dosen

    // TULISKAN METHOD DAN OBJECT DOSEN DI SINI

    // Method Matakuliah
    
    // TULISKAN METHOD DAN OBJECT MATAKULIAH DI SINI
}
?>