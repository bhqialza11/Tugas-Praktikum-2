<?php
class Matakuliah extends CI_Controller {
    public function index() {
        $this->load->model('Matakuliah_model','matkul1');
        $this->matkul1->id=1;
        $this->matkul1->nama='Pemrograman Web 2';
        $this->matkul1->sks='3';
        $this->matkul1->kode='12008';


        $this->load->model('Matakuliah_model','matkul2');
        $this->matkul2->id=2;
        $this->matkul2->nama='Basis Data';
        $this->matkul2->sks='4';
        $this->matkul2->kode='12009';

        $this->load->model('Matakuliah_model','matkul3');
        $this->matkul3->id=3;
        $this->matkul3->nama='Statistik dan Probabilitas';
        $this->matkul3->sks='2';
        $this->matkul3->kode='12005';
        



        $list_matkul = [$this->matkul1, $this->matkul2, $this->matkul3];
        $data['list_matkul']=$list_matkul;
        $this->load->view('layouts/header');
        $this->load->view('matakuliah/index',$data);
        $this->load->view('layouts/footer');
    } 
}
?>