<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        h2{
            text-align:center;
        }
        table{
            text-align:center;         
        }
    </style>

    <title>Daftar Dosen</title>
  </head>
  <body>

    <br>
    <h2>Daftar Dosen</h2>
    <br>
    <div class="container-fluid">
        <table class="table table-bordered">
            <thead class="table-secondary">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">NIDN</th>
                    <th scope="col">Pendidikan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $nomor = 1;
                    foreach($list_dsn as $dsn){
                ?>

                <tr>
                    <td><?= $dsn->id ?></td>
                    <td><?= $dsn->nidn ?></td>
                    <td><?= $dsn->pendidikan ?></td>
                </tr>
                
                <?php
                    $nomor++;
                    }
                ?>
            </tbody>
        </table>
    </div>
    
  </body>
</html>
