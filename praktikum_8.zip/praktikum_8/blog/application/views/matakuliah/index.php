<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        h2{
            text-align:center;
        }
        table{
            text-align:center;         
        }
    </style>

    <title>Daftar Matakuliah</title>
  </head>
  <body>
    <br>
    <h2>Daftar Matakuliah</h2>
        <table class="table table-bordered" border="1">
            <thead class="table-secondary">
                <tr>
                    <th>Nomor</th>
                    <th>Nama</th>
                    <th>Sks</th>
                    <th>Kode</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $nomor=1;
                    foreach($matakuliah as $matkul){
                ?>
                <tr>
                    <td><?=$nomor?></td>
                    <td><?=$matkul->nama?></td>
                    <td><?=$matkul->sks?></td>
                    <td><?=$matkul->kode?></td>
                </tr>
                
                <?php
                $nomor++;
                
                }
                ?>
            </tbody>
        </table>

  </body>
</html>