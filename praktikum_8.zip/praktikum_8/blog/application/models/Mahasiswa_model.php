<?php
class Mahasiswa_model extends CI_Model{
    // Buat Property atau variable
    public $id, $nama, $nim, $gender,$tmp_lahir, $tgl_lahir, $ipk;

    public function getAll(){
        $query = $this->db->get('mahasiswa');
        return $query->result();
    }
    public function getById($id){
        $query = $this-> db-> get_where('mahasiswa', ['id'=> $id]);
        return $query->row();
    }
}
?>