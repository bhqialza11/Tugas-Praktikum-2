<?php
class Matakuliah_model extends CI_Model{
    public $nama, $sks, $kode;
    
    public function getAll(){
        $query = $this->db->get('mata_kuliah');
        return $query->result();
    }
    public function getById($id){
        $query = $this-> db-> get_where('mata_kuliah', ['id'=> $id]);
        return $query->row();
    }
}
?>